/**
 * RestaurantOS - Authentication Service
 * Real Google OAuth (via Supabase Auth) + real email OTP verification.
 * No fake/demo account picker -- every sign-in goes through Supabase's
 * actual GoTrue backend when configured (see src/config.js).
 *
 * Public API is unchanged from the previous version so navbarAuth.js and
 * entryModal.js work without modification:
 *   authService.user, .ensureCustomerSession(), .getActiveRole(),
 *   .canAccessPage(), .loginWithGoogle(), .logout(), .setUserRole(),
 *   .onAuthStateChanged()
 *
 * New methods added for email OTP verification:
 *   .sendEmailOtp(email), .verifyEmailOtp(email, token)
 */

import { dbEngine } from './supabaseClient.js';

const AUTH_STORAGE_KEY = 'rest_os_google_user';

export const ROLE_PERMISSIONS = {
  Customer: {
    name: 'Customer',
    allowedPages: ['index.html', 'customer.html', 'pos.html', 'payment.html', 'queue.html'],
    defaultRedirect: 'customer.html',
    description: 'Dedicated Customer Space: Menu Explorer, Chef Notes, Order Summary & Payment Gateway.'
  },
  Kitchen: {
    name: 'Kitchen',
    allowedPages: ['index.html', 'kds.html', 'queue.html'],
    defaultRedirect: 'kds.html',
    description: 'Kitchen Display System & food prep orders with Cooking Notes.'
  },
  Waiter: {
    name: 'Waiter',
    allowedPages: ['index.html', 'customer.html', 'pos.html', 'kds.html', 'digital_twin.html', 'payment.html', 'queue.html'],
    defaultRedirect: 'pos.html',
    description: 'POS Terminal, table status, KDS & payment processing.'
  },
  Manager: {
    name: 'Manager',
    allowedPages: ['index.html', 'customer.html', 'pos.html', 'kds.html', 'analytics.html', 'digital_twin.html', 'inventory.html', 'opscopilot.html', 'payment.html', 'queue.html'],
    defaultRedirect: 'analytics.html',
    description: 'Full managerial access across all operational modules.'
  }
};


class AuthService {
  constructor() {
    this.user = this.loadStoredUser();
    this.listeners = [];
    this.clientId = window.GOOGLE_CLIENT_ID || '';
    this.pendingOtpEmail = null;
    this.initSupabaseSessionSync();
  }

  // ---------------------------------------------------------------------
  // Real backend session sync
  // ---------------------------------------------------------------------

  // If Supabase is configured, keep authService.user in lockstep with the
  // real GoTrue session -- this is what makes Google OAuth, email OTP, and
  // page refreshes all behave consistently instead of relying on a
  // separate locally-faked login state.
  initSupabaseSessionSync() {
    if (!dbEngine.supabase || !dbEngine.hasValidSupabaseConfig()) {
      if (!dbEngine.supabase) {
        console.info('RestaurantOS: Supabase not configured (src/config.js is empty). Running in local demo mode -- Google/OTP sign-in will show a setup notice instead of failing silently.');
      }
      return;
    }

    // Restore any existing real session (e.g. after an OAuth redirect back)
    dbEngine.supabase.auth.getSession().then(({ data }) => {
      if (data?.session?.user) this.handleSupabaseSession(data.session);
    });

    dbEngine.supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        this.handleSupabaseSession(session);
      } else if (event === 'SIGNED_OUT') {
        this.saveUser(null);
      }
    });
  }

  // Turn a real Supabase session into the same user shape the rest of the
  // app already expects (id/name/email/picture/role/auth_provider).
  async handleSupabaseSession(session) {
    const authUser = session.user;
    const meta = authUser.user_metadata || {};
    const provider = authUser.app_metadata?.provider || 'email';

    // Look up the role from the real profiles table (created automatically
    // by the on_auth_user_created trigger in src/db/auth_schema.sql). Falls
    // back to the previously chosen role, then Customer.
    let role = this.user?.role || 'Customer';
    try {
      const { data, error } = await dbEngine.supabase
        .from('profiles')
        .select('role, full_name, avatar_url')
        .eq('id', authUser.id)
        .single();
      if (!error && data) {
        role = data.role || role;
      }
    } catch (e) {
      console.warn('Profile lookup notice:', e.message);
    }

    const sessionUser = {
      id: authUser.id,
      name: meta.full_name || meta.name || authUser.email.split('@')[0],
      email: authUser.email,
      picture: meta.avatar_url || meta.picture || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(authUser.email)}`,
      role,
      auth_provider: provider,
      email_verified: !!authUser.email_confirmed_at,
      signed_in_at: new Date().toISOString()
    };

    await dbEngine.syncUserProfile(sessionUser);
    this.saveUser(sessionUser);
    this.showToast(`Signed in as ${sessionUser.name} (${sessionUser.email})`);
    this.closeAuthModal();
  }

  // ---------------------------------------------------------------------
  // Session state (unchanged from previous version)
  // ---------------------------------------------------------------------

  ensureCustomerSession() {
    if (!this.user || this.user.role !== 'Customer') {
      const customerUser = {
        id: `cust_${Date.now()}`,
        name: this.user ? this.user.name : 'Guest',
        email: this.user ? this.user.email : null,
        picture: this.user ? this.user.picture : `https://api.dicebear.com/7.x/avataaars/svg?seed=guest${Date.now()}`,
        role: 'Customer',
        auth_provider: 'guest',
        signed_in_at: new Date().toISOString()
      };
      this.saveUser(customerUser);
    }
    return this.user;
  }

  getActiveRole() {
    const roleName = this.user ? this.user.role : 'Customer';
    return ROLE_PERMISSIONS[roleName] || ROLE_PERMISSIONS.Customer;
  }

  canAccessPage(pagePath) {
    if (!pagePath) return true;
    const cleanName = pagePath.split('/').pop().split('?')[0] || 'index.html';
    if (cleanName === 'index.html' || cleanName === '') return true;

    const rolePerms = this.getActiveRole();
    return rolePerms.allowedPages.includes(cleanName);
  }

  loadStoredUser() {
    try {
      const stored = localStorage.getItem(AUTH_STORAGE_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch (e) {
      console.error('Error loading auth state:', e);
      return null;
    }
  }

  saveUser(user) {
    this.user = user;
    if (user) {
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(AUTH_STORAGE_KEY);
    }
    this.notifyListeners();
    window.dispatchEvent(new CustomEvent('auth:changed', { detail: { user } }));
  }

  // ---------------------------------------------------------------------
  // Real Google Sign-In (Supabase OAuth) -- replaces the old fake modal
  // ---------------------------------------------------------------------

  loginWithGoogle() {
    if (!dbEngine.supabase || !dbEngine.hasValidSupabaseConfig()) {
      this.showAuthSetupNotice('Google Sign-In');
      return;
    }
    try {
      dbEngine.supabase.auth.signInWithOAuth({
        provider: 'google',
        options: { redirectTo: window.location.origin + window.location.pathname }
      });
      // Browser navigates to Google's real consent screen here; on return,
      // initSupabaseSessionSync()'s onAuthStateChange listener picks up
      // the session and calls handleSupabaseSession().
    } catch (err) {
      console.warn('Google OAuth redirect notice:', err.message);
      this.showToast('Could not start Google Sign-In. Check your Supabase Google provider setup.');
    }
  }

  // ---------------------------------------------------------------------
  // Real Email OTP verification
  // ---------------------------------------------------------------------

  // Step 1: send a one-time code to the given email via Supabase Auth.
  async sendEmailOtp(email) {
    if (!dbEngine.supabase || !dbEngine.hasValidSupabaseConfig()) {
      this.showAuthSetupNotice('Email OTP verification');
      return { ok: false, reason: 'not_configured' };
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || '')) {
      this.showToast('Enter a valid email address first.');
      return { ok: false, reason: 'invalid_email' };
    }
    try {
      const { error } = await dbEngine.supabase.auth.signInWithOtp({
        email,
        options: { shouldCreateUser: true }
      });
      if (error) {
        this.showToast(`Could not send code: ${error.message}`);
        return { ok: false, reason: error.message };
      }
      this.pendingOtpEmail = email;
      this.showToast(`Verification code sent to ${email}`);
      return { ok: true };
    } catch (e) {
      this.showToast('Could not send verification code. Try again.');
      return { ok: false, reason: e.message };
    }
  }

  // Step 2: verify the 6-digit code the user received by email.
  async verifyEmailOtp(email, token) {
    if (!dbEngine.supabase || !dbEngine.hasValidSupabaseConfig()) {
      this.showAuthSetupNotice('Email OTP verification');
      return { ok: false, reason: 'not_configured' };
    }
    try {
      const { data, error } = await dbEngine.supabase.auth.verifyOtp({
        email,
        token,
        type: 'email'
      });
      if (error || !data?.session) {
        this.showToast(`Verification failed: ${error ? error.message : 'invalid code'}`);
        return { ok: false, reason: error ? error.message : 'invalid_code' };
      }
      this.pendingOtpEmail = null;
      await this.handleSupabaseSession(data.session);
      return { ok: true };
    } catch (e) {
      this.showToast('Verification failed. Check the code and try again.');
      return { ok: false, reason: e.message };
    }
  }

  showAuthSetupNotice(featureName) {
    this.showToast(`${featureName} needs Supabase credentials in src/config.js first.`);
  }

  closeAuthModal() {
    const modal = document.getElementById('auth-modal');
    if (modal) modal.remove();
  }

  // ---------------------------------------------------------------------
  // Logout / role switching (unchanged)
  // ---------------------------------------------------------------------

  logout() {
    const user = this.user;
    this.saveUser(null);
    if (dbEngine.supabase) {
      try {
        dbEngine.supabase.auth.signOut();
      } catch (e) {}
    }
    this.showToast(user ? `Signed out ${user.name}` : 'Signed out');
  }

  setUserRole(role) {
    if (this.user) {
      this.user.role = role;
      this.saveUser(this.user);
      dbEngine.syncUserProfile(this.user);
      this.showToast(`Role updated to ${role}`);
    }
  }

  showToast(message) {
    const existing = document.getElementById('auth-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.id = 'auth-toast';
    toast.className = 'auth-toast-notification';
    toast.innerHTML = `
      <div class="toast-content">
        <svg width="18" height="18" viewBox="0 0 24 24" style="flex-shrink:0;">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.1c-.22-.66-.35-1.36-.35-2.1s.13-1.44.35-2.1V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
        </svg>
        <span>${message}</span>
      </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  onAuthStateChanged(callback) {
    if (typeof callback === 'function') {
      this.listeners.push(callback);
    }
  }

  notifyListeners() {
    this.listeners.forEach(cb => cb(this.user));
  }
}

export const authService = new AuthService();
window.authService = authService;
